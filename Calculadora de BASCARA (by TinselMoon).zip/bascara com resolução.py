from time import sleep
print ("""x-x-x-CALCULADORA DE BHASKARA-x-x-x""")
sleep(1)
print('''FEITA POR: TinselMoon 
INSCREVA-SE NO MEU CANAL PARA MAIS CONTEÚDOS COMO ESSE!''')
sleep(1)
while True:
    a = float(input('Indique o valor de A: '))
    sleep(1)
    b = float(input('Indique o valor de B: '))
    sleep(1)
    c = float(input('Indique o valor de C: '))
    sleep(1)
    print('Iniciando calculo...')
    sleep(1)
    delta = b**2 - 4*a*c
    print('Para calcular o delta usamos a seguinte fórmula: B² - 4 * a * c\n')
    sleep(1)
    print(f'O valor de delta é: {b:.2f}² - 4 * {a:.2f} * {c:.2f} = {delta:.2f}\n')
    sleep(1)
    if delta == 0:
        print('Delta possuí o valor 0, então tanto X1 quanto X2 terão o mesmo valor! ')
    if delta < 0:
        enter = input('Delta possuí um número negativo! Pressione enter para fechar. ')
        break
    print('Sabendo o valor de delta, iremos para a fórmula de báscara! \n')
    sleep(1)
    x1 = (-b + (delta**(1/2)))/2*a
    x2 = (-b - (delta**(1/2)))/2*a
    print(f'''Calculando X1:
-{b:.2f} + √{delta:.2f} / 2 * {a:.2f}

X1 = {x1:.2f}''')
    print(f'''
Calculando X2:

-{b:.2f} - √{delta:.2f} / 2 * {a:.2f}

X2 = {x2:.2f}
''')
    r = str(input('Deseja utilizar a ferramenta novamente? (S/N) ')).upper()
    if r == 'N':
        break